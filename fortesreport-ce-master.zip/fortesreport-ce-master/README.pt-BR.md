<!-- # - logo -->
[<img src="https://www.fortestecnologia.com.br/wp-content/themes/atratis/images/logo-fortes-tecnologia.gif" alt="drawing" width="500"/>](https://www.fortestecnologia.com.br/)

<!-- # - about -->
# FortesReport Edição da comunidade
O FortesReport é um poderoso gerador de relatórios disponível como um pacote de componentes para Delphi. No FortesReport, os relatórios são compostos por bandas que possuem funções específicas no fluxo de impressão. Você define agrupamentos, subníveis e totais simplesmente por relação hierárquica entre faixas. Além disso, o FortesReport possui uma rica paleta de componentes para texto, gráficos, fórmulas, códigos de barras, filtros e layout.

<!-- # - lang -->
#
[<img src="https://raw.githubusercontent.com/hampusborgos/country-flags/main/svg/gb.svg" alt="drawing" height="26"/>](https://github.com/fortesinformatica/fortesreport-ce/blob/master/README.md)
[<img src="https://raw.githubusercontent.com/hampusborgos/country-flags/main/svg/br.svg" alt="drawing" height="26"/>](https://github.com/fortesinformatica/fortesreport-ce/blob/master/README.pt-BR.md)